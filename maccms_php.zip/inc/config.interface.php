<?php
define("app_interfacepass","111222");        //站外入库安全验证密码
?>