<?php
define("app_buymin",10);       //最小充值金额单位RMB元
define("app_buyexc",1);       //1元RMB兑换多少个积分
define("app_buyid","201238303611");      //支付接口作者ID
define("app_buykey","wxkhhbr8x9aew6c6");      //支付接口密钥key
?>